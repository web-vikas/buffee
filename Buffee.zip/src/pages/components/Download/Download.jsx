import React from 'react'
import './download.css'
import Avatar from './../../assest/images/avatar.jpg'
export default function Download() {
    return (
        <div>
            <div className="downlaod-container">
                <div className="srf">
                    <h2 className='movie-title'>" Avatar "</h2>
                </div>
                <div className="ig">
                    <img src={Avatar} alt="movie-poster" />
                </div>
                <ul className="details">
                    <li><strong>Movie Name :</strong> Avatar</li>
                    <li><strong>Quality :</strong> 360,480,720,1080</li>
                    <li><strong>Launguage :</strong> 360,480,720,1080</li>
                    <li><strong>Director :</strong> 360,480,720,1080</li>
                    <li><strong>Genres :</strong> 360,480,720,1080</li>
                </ul>
                <div className="screeshots">
                    <div className="column">
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                        <img src="https://www.w3schools.com/w3images/paris.jpg"  alt="screenshots"/>
                    </div>
                </div>
                <div className="dwd-lc">
                    <div className="dl-row">
                        <h2>720p </h2><a href="/">Download</a>
                    </div>
                    <div className="dl-row">
                        <h2>720p </h2><a href="/">Download</a>
                    </div>
                    <div className="dl-row">
                        <h2>720p </h2><a href="/">Download</a>
                    </div>
                    <div className="dl-row">
                        <h2>720p </h2><a href="/">Download</a>
                    </div>
                </div>
            </div>
        </div>
    )
}
