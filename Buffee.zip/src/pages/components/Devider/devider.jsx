import React from 'react'
import './devider.css'
const devider = (props) => {
    return (
        <div className='devider'>
            <h2>{props.title}</h2>
        </div>
    )
}
export default devider 