
import './ham.css';

const Ham = () => {
    return (
        <>
            <button className="bar hide-for-desktop">
                <span className=""></span>
                <span className="middle"></span>
                <span className=""></span>
            </button>
        </>
    )
}
export default Ham;