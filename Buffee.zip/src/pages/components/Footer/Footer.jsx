import React from 'react'
import './Footer.css'
export const Footer = () => {
  return (
    <>
       <footer className='footer'>
        <h2>All RIghts Reserved &#169; {new Date().getFullYear()} Buffee </h2>
       </footer>
    </>
  )
}
