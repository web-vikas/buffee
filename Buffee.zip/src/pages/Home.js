import React from 'react'
import Devider from './components/Devider/devider'
import Header from './components/Header/Header'
import Card from './components/Cards/card'
import './Home.css'
import DrStrange from './assest/images/drStrange.jpg'
import Avatar from './assest/images/avatar.jpg'
import BlackPanther from './assest/images/blackPanther.jpg'
import IronMan from './assest/images/ironMan.jpg'
import Spider from './assest/images/spider.jpg'
import { Footer } from './components/Footer/Footer'
export default function Home() {
  return (
    <>
      <Header />
      <Devider
        title="Popular Movies"
      />
      <div className='HorigentalSLider'>
        <div className='slider'>
          <Card
            backGround={DrStrange}
          />
          <Card
            backGround={Avatar}
          />
          <Card
            backGround={BlackPanther}
          />
          <Card
            backGround={IronMan}
          />
          <Card
            backGround={Spider}
          />

        </div>
      </div>
      <Devider
        title="Just Arrived"
      />
      <div className='jus-arrived'>
        <Card
          backGround={DrStrange}
        />
        <Card
          backGround={Avatar}
        />
        <Card
          backGround={BlackPanther}
        />
        <Card
          backGround={IronMan}
        />
        <Card
          backGround={Spider}
        />
        <Card
          backGround={DrStrange}
        />
      </div>
      <Footer/>
    </>
  )
} 
