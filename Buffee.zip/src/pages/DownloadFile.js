import Download from './components/Download/Download'

import React from 'react'
import Header from './components/Header/Header'
import {Footer} from './components/Footer/Footer'
export function DownloadFile() {
  return (
    <div>
      <Header/>
      <Download/>
      <Footer/>
    </div>
  )
}
